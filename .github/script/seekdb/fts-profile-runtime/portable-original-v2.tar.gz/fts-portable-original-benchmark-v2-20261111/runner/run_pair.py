#!/usr/bin/env python3
"""Portable FTS v2. Offline check by default; explicit run only after review.

No GitHub dependency, download, upload, build, global kill or system setting.
Only own container task window/self-stop deadline is attested, never lease/host.
"""
import argparse


import ctypes


import datetime as dt


import hashlib


import importlib.util


import json


import os


from pathlib import Path


import re


import resource


import shutil


import signal


import socket


import stat


import subprocess


import sys


import tarfile


import threading


import time


import traceback


import uuid


INVENTORY_SHA = 'f36e2d1c8aaabd3e9ffc4f8e3635defca6dc3046e3d575e6e73165fa8d80a135'


DATA_SHA = 'bc385b3c9586d40d667093947be20a8714ed65301eae68487af8fac22956d235'


CONFIG = dict(ROWS='20000', BATCH='500', ROUNDS='3000', QUERY_ROUNDS='200', SAMPLES='3', WARMUP='30', SKIP_LOAD='0')


PARAMETERS = ['memory_budget=4G', 'vector_memory_limit=1G', 'datafile_maxsize=2G', 'log_disk_size=2G']


HITS = dict(query_cn_hits=8001, query_beng_hits=11000, query_mixed_hits=7332, query_limit_hits=20)


CATEGORIES = dict(build=['build_ik_all_sec', 'build_ik_content_sec', 'build_beng_en_sec'],
                  tokenize=['tokenize_ik_avg_ms', 'tokenize_beng_avg_ms'],
                  query=['query_cn_avg_ms', 'query_beng_avg_ms', 'query_mixed_avg_ms', 'query_limit_avg_ms'])


IDENTITIES = {
    'baseline': dict(bytes=1332362136, sha256='fa2be2a166c042421080e142adbb98b83f277be6f77b2a47ce63dc69f0f6db03',
        buildId='983ae843c7765c615f6a3ba870bdbd65b5d86c74', commit='b14755bed10d1399cf7d1dca6444cfa757727b21'),
    'candidate': dict(bytes=1332371664, sha256='9f2cef74d9bcee62ef155531fc25eec0292eb94c25ce531bc31750b0df8dcf0b',
        buildId='29197aa40e7b172beb280c49dfca1aaa8a05bc01', commit='b9637d5e792cce0e461a06eee2df91036a3ff37a'),
}


CLIENT = dict(bytes=14592368, sha256='798aa952d536563ee0291e69251a6d0cd0d85e0c470d5499768fa0731ff3c1be')


MYSQLTEST = dict(bytes=13994832, sha256='64e0323b385af2831c5b166a375e8320ec40e3ead0bd925295de1b8f5a2196c6')


METRIC_RE = re.compile(r'^\s*([A-Za-z0-9_]+):\s*([-+]?(?:\d+(?:\.\d*)?|\.\d+))\s*$')


SAMPLE_RE = re.compile(r'^\s*(select1|tokenize_ik|tokenize_beng|query_cn|query_beng|query_mixed|query_limit): sample=(\d+)/(\d+) rounds=(\d+) total_ms=([0-9.]+) avg_ms=([0-9.]+)\s*$')


RELATED = {'seekdb', 'observer', 'obclient', 'mysql', 'mysqltest', 'gcc', 'g++', 'cc', 'c++', 'cc1', 'cc1plus',
    'clang', 'clang++', 'ld', 'ld.lld', 'rustc', 'cargo', 'cmake', 'ninja', 'make', 'ccache', 'hipcc', 'nvcc',
    'rocprof', 'rocprofv2', 'rocblas-bench', 'torchrun', 'mpirun', 'llama-server', 'vllm'}


class Blocked(RuntimeError): pass


def require(condition, message):
    if not condition: raise Blocked(message)


def now(): return dt.datetime.now(dt.timezone.utc)


def utc(): return now().isoformat()


def dump(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + '.partial')
    tmp.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
    tmp.replace(path)


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024**2), b''): value.update(block)
    return value.hexdigest()


def emit(value): print(json.dumps(value, sort_keys=True), flush=True)


def stamp(path):
    st = Path(path).stat()
    return dict(bytes=st.st_size, inode=st.st_ino, device=st.st_dev, mtimeNs=st.st_mtime_ns)


def positive(value):
    result = int(value)
    if result <= 0: raise argparse.ArgumentTypeError('Must be a positive integer')
    return result


def cpu_set(value):
    cpus = set()
    try:
        for part in value.split(','):
            if '-' in part:
                first, last = map(int, part.split('-'))
                if first < 0 or last < first: raise ValueError()
                cpus.update(range(first, last + 1))
            else:
                cpu = int(part)
                if cpu < 0: raise ValueError()
                cpus.add(cpu)
        if len(cpus) < 2: raise ValueError()
    except (ValueError, TypeError):
        raise argparse.ArgumentTypeError('Use at least two CPU IDs, e.g. 4,5 or 4-7')
    return cpus


def instant(value):
    parsed = dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(parsed.tzinfo is not None, 'Timestamp requires an explicit timezone')
    return parsed.astimezone(dt.timezone.utc)


def regular(path, executable=False):
    path = Path(path).absolute()
    require(not path.is_symlink() and path.is_file(), 'Expected a non-symlink regular file: ' + str(path))
    require(stat.S_ISREG(path.stat().st_mode), 'Not a regular file: ' + str(path))
    if executable: require(os.access(path, os.X_OK), 'Not executable: ' + str(path))
    return path.resolve()


def proc_snapshot():
    rows = {}
    for directory in Path('/proc').iterdir():
        if not directory.name.isdigit(): continue
        try:
            text = (directory / 'stat').read_text()
            end = text.rindex(')')
            fields = text[end + 2:].split()
            rows[int(directory.name)] = dict(pid=int(directory.name), comm=text[text.index('(')+1:end],
                state=fields[0], ppid=int(fields[1]),pgrp=int(fields[2]),session=int(fields[3]), cpuTicks=int(fields[11])+int(fields[12]), startTicks=int(fields[19]))
        except FileNotFoundError: continue
        except PermissionError as exc: raise Blocked('Cannot read global process state: ' + str(exc))
    return rows


def related_name(name):
    return name in RELATED or any(name.startswith(prefix) for prefix in ('clang-', 'gcc-', 'g++-', 'rustc', 'nvcc', 'vllm'))


def process_observation(seconds):
    before = proc_snapshot()
    start = time.monotonic()
    time.sleep(seconds)
    after = proc_snapshot()
    span = time.monotonic() - start
    own = {os.getpid()}
    # Ignore only our process ancestry/descendants, not other Jupyter tasks.
    cursor = os.getpid()
    while cursor in after and after[cursor]['ppid'] not in own:
        cursor = after[cursor]['ppid']
        own.add(cursor)
        if cursor <= 1: break
    changed = True
    while changed:
        changed = False
        for pid, row in after.items():
            if row['ppid'] in own and pid not in own and row['ppid'] not in (0, 1):
                # An ancestor's other children are foreign; only root at our PID.
                parent = row['ppid']
                while parent in after and parent != os.getpid() and parent > 1:
                    parent = after[parent]['ppid']
                if parent == os.getpid(): own.add(pid); changed = True
    hz = os.sysconf('SC_CLK_TCK')
    rows = []
    for pid, row in after.items():
        previous = before.get(pid)
        ticks = max(0, row['cpuTicks'] - previous['cpuTicks']) if previous and previous['startTicks'] == row['startTicks'] else 0
        row = dict(row, observedCpuCores=ticks / hz / span, ownedOrAncestor=pid in own)
        rows.append(row)
    related = [r for r in rows if related_name(r['comm']) and not r['ownedOrAncestor'] and r['state'] != 'Z']
    active = [r for r in rows if r['observedCpuCores'] >= .25 and not r['ownedOrAncestor'] and r['state'] != 'Z']
    return dict(utc=utc(),intervalSeconds=span,processes=rows,foreignRelated=related,foreignActive=active,
        scope='Processes visible in this container PID namespace; not proof of physical-host exclusivity',
        globalArgumentsOmitted='Only process names, IDs, state and CPU deltas, to avoid credentials or unrelated private data')


def resources(root):
    text = Path('/proc/meminfo').read_text()
    avail = int(re.search(r'^MemAvailable:\s*(\d+)', text, re.M).group(1)) * 1024
    total = int(re.search(r'^MemTotal:\s*(\d+)', text, re.M).group(1)) * 1024
    cgroup = {}
    for name in ('memory.max', 'memory.current', 'cpu.max', 'cpu.stat'):
        path = Path('/sys/fs/cgroup') / name
        if path.is_file(): cgroup[name] = path.read_text().strip()
    effective = avail
    if cgroup.get('memory.max', 'max') != 'max':
        effective = min(effective, int(cgroup['memory.max']) - int(cgroup.get('memory.current', '0')))
    return dict(utc=utc(),memAvailableBytes=avail,effectiveMemAvailableBytes=effective,memTotalBytes=total,
        diskFreeBytes=shutil.disk_usage(root).free,affinity=sorted(os.sched_getaffinity(0)),cpuCount=os.cpu_count(),
        uname=list(os.uname()),loadavg=list(os.getloadavg()),cgroup=cgroup,
        nofileLimit=list(resource.getrlimit(resource.RLIMIT_NOFILE)),coreLimit=list(resource.getrlimit(resource.RLIMIT_CORE)),
        interfaces=Path('/proc/net/dev').read_text())


def require_resources(snapshot, args):
    require(snapshot['effectiveMemAvailableBytes'] >= args.min_memory_gib * 1024**3, 'Insufficient memory; do not reduce fixed database limits')
    require(snapshot['diskFreeBytes'] >= args.min_disk_gib * 1024**3, 'Insufficient free disk')
    require(len(snapshot['affinity']) >= 2, 'At least two allowed CPUs required')
    require(snapshot['nofileLimit'][0] >= 8192, 'Insufficient open-file limit; runner will not change system settings')
    nonloopback = [line.split(':', 1)[0].strip() for line in snapshot['interfaces'].splitlines()[2:] if ':' in line and line.split(':', 1)[0].strip() != 'lo']
    require(nonloopback, 'Only loopback interfaces exposed; unchanged Linux UUID initializer requires a non-loopback MAC')


def _terminate_created_group(process):
    """Terminate/reap only the session/process group created by this Popen."""
    alive=process.poll() is None
    if alive:
        require(os.getpgid(process.pid)==process.pid,'Command no longer owns its created process group')
    members=[r for r in proc_snapshot().values() if r.get('pgrp')==process.pid and r.get('session')==process.pid]
    if alive or members:
        try:os.killpg(process.pid,signal.SIGTERM)
        except ProcessLookupError:pass
    try:process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        if process.poll() is None:require(os.getpgid(process.pid)==process.pid,'Command group changed before SIGKILL')
        try:os.killpg(process.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        process.wait(timeout=5)
    # Descendants in the same newly created session may outlive its leader.
    deadline=time.monotonic()+5
    while True:
        members=[r for r in proc_snapshot().values() if r.get('pgrp')==process.pid and r.get('session')==process.pid]
        live=[r for r in members if r['state']!='Z']
        for member in members:
            try:os.waitpid(member['pid'],os.WNOHANG)
            except ChildProcessError:pass
        if not live:return True
        if time.monotonic()>=deadline:
            try:os.killpg(process.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            for member in live:
                try:os.waitpid(member['pid'],os.WNOHANG)
                except ChildProcessError:pass
            return False
        time.sleep(.05)


def run_command(command, output, env, timeout, input_bytes=None):
    command=list(map(str,command))
    receipt=dict(command=command,startedUtc=utc(),timeoutSeconds=timeout,output=output.name)
    start=time.monotonic();process=None;error=None
    with output.open('wb') as stream:
        try:
            process=subprocess.Popen(command,stdin=subprocess.PIPE if input_bytes is not None else subprocess.DEVNULL,
                stdout=stream,stderr=subprocess.STDOUT,env=env,start_new_session=True)
            receipt['createdProcessGroup']=process.pid
            process.communicate(input_bytes,timeout=timeout)
        except BaseException as exc:
            error=exc
            receipt.update(timedOut=isinstance(exc,subprocess.TimeoutExpired),interrupted=not isinstance(exc,subprocess.TimeoutExpired),
                exceptionType=type(exc).__name__,error=str(exc))
            if process is not None:
                try:receipt['createdGroupCleanedAndReaped']=_terminate_created_group(process)
                except BaseException as cleanup_error:
                    receipt.update(createdGroupCleanedAndReaped=False,groupCleanupError=str(cleanup_error))
        finally:
            receipt['exitCode']=process.returncode if process is not None else None
            receipt.update(finishedUtc=utc(),elapsedSeconds=time.monotonic()-start)
    receipt.update(outputBytes=output.stat().st_size,outputSha256=sha(output))
    dump(output.with_name(output.name+'.receipt.json'),receipt)
    if error is not None:
        if isinstance(error,subprocess.TimeoutExpired):return receipt
        raise error
    return receipt


def checked(command, output, env, timeout=30, input_bytes=None):
    receipt=run_command(command,output,env,timeout,input_bytes)
    require(receipt['exitCode'] == 0 and not receipt.get('timedOut'), 'Command failed: '+output.name)
    return receipt


def runtime_env(args):
    env = {key:os.environ[key] for key in ('PATH','HOME','LANG','LC_ALL','LC_CTYPE','TZ','USER','LOGNAME','TMPDIR','TMP','TEMP') if key in os.environ}
    env['LD_LIBRARY_PATH'] = ':'.join(str(Path(p).resolve()) for p in args.library_dir)
    env['PATH'] = str(Path(args.obclient).absolute().parent) + os.pathsep + env.get('PATH', '')
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    return env


def verify_runtime(args, out, env):
    identities = {}
    for role in ('baseline', 'candidate'):
        path = regular(getattr(args, role+'_elf'), executable=True)
        pinned = IDENTITIES[role]
        start = stamp(path)
        require(start['bytes'] == pinned['bytes'], role+' ELF size mismatch')
        with path.open('rb') as f: require(f.read(4) == b'\x7fELF', role+' is not an ELF')
        # Mandatory actual target bytes, including each new consumer's first copy.
        require(sha(path) == pinned['sha256'], role+' actual received ELF SHA256 mismatch')
        require(stamp(path) == start, role+' ELF changed while hashing')
        notes=out/(role+'-notes.log');version=out/(role+'-version.log');loader=out/(role+'-ldd.log')
        checked(['readelf','-n',path],notes,env)
        require(re.findall(r'Build ID:\s*([0-9a-f]+)',notes.read_text()) == [pinned['buildId']], role+' BuildID mismatch')
        checked([path,'--version'],version,env)
        require(pinned['commit'] in version.read_text(), role+' embedded version mismatch')
        checked(['ldd',path],loader,env)
        require('not found' not in loader.read_text(),role+' has missing libraries')
        aio = re.findall(r'^\s*(libaio\S*)\s+=>\s+(\S+)\s+\(',loader.read_text(),re.M)
        require(len(aio)==1,'Expected one resolved official libaio')
        aio_path=Path(aio[0][1]).resolve()
        checked(['readelf','-d',aio_path],out/(role+'-libaio-dynamic.log'),env)
        sonames=re.findall(r'\(SONAME\).*\[([^\]]+)\]',(out/(role+'-libaio-dynamic.log')).read_text())
        require(aio[0][0]=='libaio.so.1t64' and len(sonames)==1 and sonames[0] in ('libaio.so.1','libaio.so.1t64'),'Unreviewed libaio SONAME/compatibility alias')
        identities[role]=dict(path=str(path),**pinned,fileStamp=start,actualTargetHashVerified=True,
            libaio=dict(neededSoname=aio[0][0],actualSoname=sonames[0],compatibilityAlias=sonames[0]!=aio[0][0],resolvedPath=str(aio_path),bytes=aio_path.stat().st_size,sha256=sha(aio_path)))
    for label,expected in [('obclient',CLIENT),('mysqltest',MYSQLTEST)]:
        value=getattr(args,label)
        if value is None: continue
        path=regular(value, executable=True)
        require(not any(ch.isspace() for ch in str(path)), 'Original MYSQL command requires a client path without whitespace')
        require(path.stat().st_size==expected['bytes'] and sha(path)==expected['sha256'],label+' exact official client identity mismatch')
        checked([path,'--version'],out/(label+'-version.log'),env)
        checked(['ldd',path],out/(label+'-ldd.log'),env)
        require('not found' not in (out/(label+'-ldd.log')).read_text(),label+' missing libraries')
        identities[label]=dict(path=str(path),**expected)
    require(identities['baseline']['libaio']['sha256']==identities['candidate']['libaio']['sha256'],'Roles resolve different libaio')
    dump(out/'runtime-verification.json',identities)
    return identities


CLEANUP_RESERVE_SECONDS=340


def required_pair_budget(args):
    # start60 + ready(+10) + parameter30 + benchmark + scorer30x2 +
    # untimed samples60 + stop65 + destroy65 + logs120 + evidence60 + metadata60.
    return 2*(60+args.ready_timeout_seconds+10+30+args.role_timeout_seconds+60+60+65+65+120+60+60)


def guard_processes(observation):
    require(not observation['foreignRelated'],'Foreign SQL/compiler/GPU-related processes present; refuse to start')
    require(not observation['foreignActive'],'Another active workload is present; refuse to start')


def gpu_observation(out, env):
    record=dict(utc=utc(),sysfs=[],nvidiaQueryAvailable=False)
    for path in sorted(Path('/sys/class/drm').glob('card*/device/gpu_busy_percent')):
        value=int(path.read_text().strip())
        record['sysfs'].append(dict(path=str(path),busyPercent=value))
        require(value==0,'GPU reports nonzero utilization; refuse to start')
    if shutil.which('nvidia-smi'):
        record['nvidiaQueryAvailable']=True
        checked(['nvidia-smi','--query-compute-apps=pid,process_name,used_memory','--format=csv,noheader,nounits'],out/'gpu-processes.log',env)
        record['nvidiaComputeRows']=(out/'gpu-processes.log').read_text().strip()
        require(not record['nvidiaComputeRows'],'GPU compute processes present; refuse to start')
    record['gpuUtilizationObservationOnly']=True
    dump(out/'gpu-observation.json',record)
    return record


def load_sdb(inputs):
    spec=importlib.util.spec_from_file_location('portable_original_sdb',inputs/'.github/script/seekdb/sdb.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def state(pid):
    return proc_snapshot().get(pid)


def reap_target(pid,stop):
    while not stop.is_set():
        try:
            waited,_=os.waitpid(pid,os.WNOHANG)
            if waited:return
        except ChildProcessError:return
        time.sleep(.1)


def check_deadline(deadline,stage):
    require(time.monotonic()<deadline,'Deadline exhausted during '+stage)


class DeadlineReader:
    def __init__(self,stream,deadline,stage):self.stream,self.deadline,self.stage=stream,deadline,stage
    def read(self,size=-1):
        check_deadline(self.deadline,self.stage)
        value=self.stream.read(size)
        check_deadline(self.deadline,self.stage)
        return value
    def __getattr__(self,name):return getattr(self.stream,name)


def deadline_sha(path,deadline):
    value=hashlib.sha256()
    with path.open('rb') as stream:
        reader=DeadlineReader(stream,deadline,'evidence hash')
        for block in iter(lambda:reader.read(4*1024**2),b''):value.update(block)
    return value.hexdigest()


def bounded_tar_add(tar,path,arcname,deadline):
    check_deadline(deadline,'evidence archive')
    info=tar.gettarinfo(str(path),arcname=arcname)
    with path.open('rb') as stream:tar.addfile(info,DeadlineReader(stream,deadline,'evidence compression'))
    check_deadline(deadline,'evidence archive')


def settle_interrupted_startup(sdb,base,binary,out):
    # The start helper has already been terminated/reaped by run_command. Its
    # daemon may have escaped into its original sdb session before cancellation.
    # Inspect only our descendants with this exact owned ELF/base-dir, and use
    # the original sdb targeted termination helper before any log/destroy step.
    receipt=dict(checkedUtc=utc(),ownedProcessesTerminated=[])
    start_receipt=out/'start.log.receipt.json'
    if start_receipt.is_file():require(json.loads(start_receipt.read_text()).get('createdGroupCleanedAndReaped',True),'Start helper group cleanup uncertain; retain owned directory')
    if not base.exists():
        receipt['baseCreated']=False;dump(out/'startup-settlement.json',receipt);return
    require(sdb.read_instance_binary(base)==binary.resolve(),'Uncertain startup marker does not match owned ELF')
    deadline=time.monotonic()+30;empty=0
    while time.monotonic()<deadline:
        rows=proc_snapshot();owned=[]
        for pid,row in rows.items():
            if row['state']=='Z':
                continue
            parent=row['ppid'];seen=set()
            while parent in rows and parent not in seen and parent!=os.getpid():seen.add(parent);parent=rows[parent]['ppid']
            if parent!=os.getpid():continue
            try:exe=Path('/proc',str(pid),'exe').resolve(strict=True)
            except FileNotFoundError:continue
            if exe==binary.resolve() and sdb.process_matches_instance(pid,base,binary):owned.append(pid)
        if not owned:
            empty+=1
            if empty>=3:break
        else:
            empty=0
            for pid in owned:
                if sdb.process_matches_instance(pid,base,binary):
                    sdb.terminate_pid(pid,base,binary);receipt['ownedProcessesTerminated'].append(pid)
        time.sleep(.1)
    require(empty>=3,'Uncertain owned daemon startup did not settle; retain directory, do not destroy')
    receipt['baseCreated']=True;receipt['settled']=True;dump(out/'startup-settlement.json',receipt)


def capture_logs(base,out,pid,deadline=None):
    deadline=deadline if deadline is not None else time.monotonic()+120
    observed=state(pid) if pid else None
    require(observed is None or observed['state']=='Z','Owned server still live; refusing final log capture')
    rows=[];total=0
    for path in sorted((base/'log').rglob('*')):
        if path.is_dir():continue
        path=regular(path);entry=dict(path=path.relative_to(base).as_posix(),**stamp(path),sha256=deadline_sha(path,deadline))
        total+=entry['bytes'];rows.append(entry)
        require(len(rows)<=128 and total<=2*1024**3,'Complete logs exceed capture cap; keep owned database and report blocker')
    missing=sorted({'log/console.log','log/seekdb.log'}-{r['path'] for r in rows})
    # Preserve every existing stopped owned log before classifying missing files.
    destination=out/'full-server-logs.tar.gz';working=destination.with_name(destination.name+'.partial')
    with tarfile.open(working,'w:gz',compresslevel=3) as tar:
        for entry in rows:
            path=base/entry['path'];bounded_tar_add(tar,path,entry['path'],deadline)
            require(stamp(path)=={k:entry[k] for k in stamp(path)} and deadline_sha(path,deadline)==entry['sha256'],'Stopped log changed during capture')
    with working.open('rb') as raw,tarfile.open(fileobj=DeadlineReader(raw,deadline,'log archive verification'),mode='r:gz') as tar:
        require([(m.name,m.size) for m in tar.getmembers()]==[(r['path'],r['bytes']) for r in rows],'Full log archive inventory mismatch')
    archive_sha=deadline_sha(working,deadline);check_deadline(deadline,'log preservation commit');working.replace(destination)
    record=dict(files=rows,rawBytes=total,fileCount=len(rows),fullBytes=True,truncated=False,
        allExistingStoppedLogBytesPreserved=True,requiredLogsPresent=not missing,missingExpectedLogs=missing,
        captureMoment='after_owned_original_sdb_stop_before_destroy',archive=dict(path=destination.name,bytes=destination.stat().st_size,sha256=archive_sha))
    dump(out/'full-server-logs.json',record)
    return record


def parse_report(path):
    result={}
    for line in path.read_text().splitlines():
        match=METRIC_RE.match(line)
        if match:result[match.group(1)]=float(match.group(2))
    for key,value in CONFIG.items():require(result.get(key.lower())==float(value),'Original report config mismatch: '+key)
    for key,value in HITS.items():require(result.get(key)==value,'Original query hit count mismatch: '+key)
    for names in CATEGORIES.values():
        for key in names:require(key in result and result[key]>0,'Missing/nonpositive scored metric: '+key)
    return result


def parse_samples(path):
    rows=[]
    for line in path.read_text().splitlines():
        match=SAMPLE_RE.match(line)
        if match:
            name,sample,total,rounds,millis,average=match.groups()
            rows.append(dict(name=name,sample=int(sample),sampleCount=int(total),rounds=int(rounds),totalMs=float(millis),avgMs=float(average),rawLine=line))
    require(len(rows)==21,'Expected all 21 original SQL-loop timing sample lines')
    return rows


def role_evidence(out,root,deadline=None):
    deadline=deadline if deadline is not None else time.monotonic()+60
    destination=root/(out.name+'-evidence.tar.gz');working=destination.with_name(destination.name+'.partial')
    files=[p for p in sorted(out.rglob('*')) if p.is_file() and not p.is_symlink()
           and not ({'database','tmp'} & set(p.relative_to(out).parts))]
    require(all(p.stat().st_size<=2*1024**3 for p in files),'Evidence file exceeds cap; retain files locally')
    with tarfile.open(working,'w:gz',compresslevel=3) as tar:
        for path in files:bounded_tar_add(tar,path,out.name+'/'+path.relative_to(out).as_posix(),deadline)
    archive_sha=deadline_sha(working,deadline);check_deadline(deadline,'role evidence commit');working.replace(destination)
    record=dict(path=str(destination),bytes=destination.stat().st_size,sha256=archive_sha,fileCount=len(files),
        excludes=['database/**','tmp/**'],availableBeforeNextRole=True)
    dump(root/(out.name+'-evidence.receipt.json'),record)
    emit(dict(event='role_evidence_ready',role=out.name,**record))
    return record


def sample_sql(bench):
    text=bench.read_text()
    ik=re.search(r'^IK_TEXT="([^"]+)"',text,re.M).group(1)
    beng=re.search(r'^BENG_TEXT="([^"]+)"',text,re.M).group(1)
    queries=re.findall(r'run_query_bench "(query_[a-z]+)" \\\n\s+"([^"]+)"',text)
    require(len(queries)==4,'Could not extract four unchanged original query texts')
    return "SET NAMES utf8mb4;\nSELECT tokenize('"+ik+"', 'ik');\nSELECT tokenize('"+beng+"', 'beng');\nSELECT COUNT(*) FROM fts_large_bench.docs;\n"+'\n'.join(q for _,q in queries)+'\n'


def run_role(role,port,args,bundle,root,env,identities,report,deadline,name=None):
    inputs=bundle/'inputs';sdb_path=inputs/'.github/script/seekdb/sdb.py';sdb=load_sdb(inputs)
    bench=inputs/'tools/benchmark/fts_large_bench.sh';scorer=inputs/'tools/benchmark/fts_large_bench_score.py'
    binary=Path(identities[role]['path']);client=Path(identities['obclient']['path'])
    out=root/(name or role);out.mkdir();base=out/'database';(out/'tmp').mkdir()
    row=dict(role=role,port=port,status='starting',startedUtc=utc(),binaryIdentity=identities[role],parameters=PARAMETERS,config=CONFIG)
    report['roles'][name or role]=row;dump(root/'report.json',report)
    pid=None;thread=None;reaper_stop=threading.Event()
    def bounded(maximum):
        left=deadline-time.monotonic()
        require(left>maximum+CLEANUP_RESERVE_SECONDS,'Full budget exhausted before '+role+' stage; preserve cleanup reserve')
        return maximum
    try:
        if name is None:require(deadline-time.monotonic()>=required_pair_budget(args)/2,'Insufficient complete next-role budget; do not start database')
        verify_bundle(bundle)
        require(stamp(binary)==identities[role]['fileStamp'],'ELF changed since target-byte verification')
        snapshot=resources(root);dump(out/'resources-before.json',snapshot);require_resources(snapshot,args)
        observation=process_observation(args.observation_seconds);dump(out/'processes-before.json',observation);guard_processes(observation)
        gpu_observation(out,env)
        require((instant(args.window_deadline_utc)-now()).total_seconds()>=max(0,deadline-time.monotonic())+args.window_buffer_seconds,'Operator stop deadline is insufficient/expired')
        with socket.socket() as probe:probe.bind(('127.0.0.1',port))
        command=[sys.executable,'-B',sdb_path,'start','--binary',binary,'--base-dir',base,'--port',str(port)]
        for p in PARAMETERS:command.extend(['--parameter',p])
        row['start']=checked(command,out/'start.log',env,bounded(60))
        # The server is a descendant owned by this fresh marker and binary.
        for _ in range(30):
            pidfile=base/'run/seekdb.pid'
            if pidfile.is_file():
                pid=int(pidfile.read_text().strip());break
            time.sleep(.1)
        row['ready']=checked([sys.executable,'-B',sdb_path,'wait-ready','--client',client,'--base-dir',base,'--port',str(port),
            '--timeout',str(args.ready_timeout_seconds)],out/'ready.log',env,bounded(args.ready_timeout_seconds+10))
        pid=sdb.inspect_instance_process(base,binary)
        require(pid is not None and state(pid)['state']!='Z','Live owned process missing')
        owned=dict(pid=pid,exe=str(Path('/proc',str(pid),'exe').resolve()),arguments=sdb.read_process_arguments(pid),
            affinity=sorted(os.sched_getaffinity(pid)),state=state(pid))
        require(owned['exe']==str(binary) and owned['affinity']==sorted(args.cpus),'Owned server ELF/affinity differs')
        dump(out/'owned-process.json',owned);row['ownedProcess']=owned
        query="select name,value from oceanbase.__all_virtual_sys_parameter_stat where name in ('memory_budget','vector_memory_limit','datafile_size','datafile_maxsize','log_disk_size','syslog_level','cpu_count') order by name;\n"
        checked([client,'-h127.0.0.1','-P'+str(port),'-uroot','-A','-N','-B','-Doceanbase'],out/'actual-parameters.log',env,bounded(30),query.encode())
        observed=dict(line.split('\t',1) for line in (out/'actual-parameters.log').read_text().splitlines())
        for setting in PARAMETERS:
            parameter_name,parameter_value=setting.split('=',1);require(observed.get(parameter_name)==parameter_value,'Observed database parameter mismatch: '+parameter_name)
        if report.get('observedParameters'):require(observed==report['observedParameters'],'A/B actual parameter values differ')
        report['observedParameters']=observed;row['observedParameters']=observed
        if name=='baseline-tiny':
            checked([client,'-h127.0.0.1','-P'+str(port),'-uroot','--default-character-set=utf8mb4'],out/'original-benchmark-setup.log',env,bounded(60),(inputs/'tools/benchmark/fts_large_bench_setup.sql').read_bytes())
            tiny_sql="SET NAMES utf8mb4; SELECT 1; SELECT COUNT(*) FROM fts_large_bench.docs; SELECT tokenize('The quick brown fox', 'beng');\n"
            checked([client,'-h127.0.0.1','-P'+str(port),'-uroot','-N','-s','--default-character-set=utf8mb4'],out/'tiny-sql.log',env,bounded(60),tiny_sql.encode())
            values=(out/'tiny-sql.log').read_text().splitlines()
            require(len(values)==3 and values[:2]==['1','0'] and isinstance(json.loads(values[2]),list),'Baseline original-setup tiny SQL preflight failed')
            row.update(status='completed',tinyOriginalSetupPreflight=True,rows=0,nativeCasesRun=0)
            emit(dict(event='baseline_tiny_preflight_completed',formalContestRun=False))
        else:
            bench_env=env.copy();mysql=f'{client} -h127.0.0.1 -P{port} -uroot --default-character-set=utf8mb4'
            bench_env.update(CONFIG,MYSQL=mysql+' -N -s',MYSQL_VERBOSE=mysql,LABEL='portable_local_'+role,
                OUTPUT=str(out/'report.txt'),TMPDIR=str(out/'tmp'))
            row['benchmarkEnvironment']={k:bench_env[k] for k in (*CONFIG,'MYSQL','MYSQL_VERBOSE','LABEL','OUTPUT','TMPDIR')}
            row['status']='benchmark_running';dump(root/'report.json',report);emit(dict(event='benchmark_started',role=role,utc=utc()))
            row['benchmark']=checked(['bash',bench],out/'benchmark.log',bench_env,bounded(args.role_timeout_seconds))
            row['metrics']=parse_report(out/'report.txt');dump(out/'metrics.json',row['metrics'])
            samples=parse_samples(out/'benchmark.log');dump(out/'samples.json',samples)
            checked([sys.executable,'-B',scorer,out/'report.txt','--json'],out/'frozen-reference-score.json',env,bounded(30))
            checked([sys.executable,'-B',scorer,out/'report.txt'],out/'frozen-reference-score.txt',env,bounded(30))
            score=json.loads((out/'frozen-reference-score.json').read_text());require(not score['config_mismatches'],'Scorer config mismatch')
            row['frozenReferenceScore']=score
            sql=sample_sql(bench);(out/'untimed-samples.sql').write_text(sql)
            checked([client,'-h127.0.0.1','-P'+str(port),'-uroot','-N','-s','--default-character-set=utf8mb4'],out/'untimed-samples.log',env,bounded(60),sql.encode())
            row.update(status='completed',finishedBenchmarkUtc=utc())
            emit(dict(event='benchmark_completed',role=role,metrics=row['metrics'],frozenReferenceScore=score['score'],formalContestRun=False))
    except Exception as exc:
        row.update(status='blocked',error=str(exc),traceback=traceback.format_exc())
        emit(dict(event='role_blocked',role=role,error=str(exc)))
    finally:
        if not row.get('start') or not row.get('ready'):
            try:settle_interrupted_startup(sdb,base,binary,out)
            except Exception as exc:row['startupSettlementError']=str(exc)
        if base.exists():
            try:
                require(not row.get('startupSettlementError'),'Interrupted startup unresolved; do not destroy')
                require(sdb.read_instance_binary(base)==binary.resolve(),'Owned marker changed; do not stop/destroy')
                if pid is None and (base/'run/seekdb.pid').is_file():pid=int((base/'run/seekdb.pid').read_text().strip())
                if pid:
                    thread=threading.Thread(target=reap_target,args=(pid,reaper_stop),daemon=True);thread.start()
                row['stop']=checked([sys.executable,'-B',sdb_path,'stop','--base-dir',base],out/'own-stop.log',env,65)
                row['fullServerLogs']=capture_logs(base,out,pid,min(time.monotonic()+120,deadline-125))
                if not row['fullServerLogs']['requiredLogsPresent']:
                    row.update(status='blocked',logCompletenessBlocker='Missing expected logs: '+','.join(row['fullServerLogs']['missingExpectedLogs']))
                row['destroy']=checked([sys.executable,'-B',sdb_path,'destroy','--base-dir',base],out/'own-destroy.log',env,65)
            except Exception as exc:
                row['cleanupError']=str(exc)
                row['retainedDatabaseDirectory']=str(base)
            finally:
                reaper_stop.set()
                if thread:thread.join(timeout=1)
        row['cleanupPassed']=not base.exists() and not row.get('startupSettlementError') and not row.get('cleanupError') and (not row.get('start') or (row.get('stop',{}).get('exitCode')==0 and row.get('destroy',{}).get('exitCode')==0))
        dump(out/'resources-after.json',resources(root));dump(out/'processes-after.json',process_observation(args.observation_seconds))
        row['finishedUtc']=utc();dump(out/'result.json',row);dump(root/'report.json',report)
    verify_bundle(bundle)
    row['evidenceArchive']=role_evidence(out,root,min(time.monotonic()+60,deadline))
    check_deadline(deadline,'role finalization')
    dump(root/'report.json',report)
    return row


def comparison(report):
    a=report['roles']['baseline']['metrics'];b=report['roles']['candidate']['metrics']
    categories={}
    for name,names in CATEGORIES.items():
        metrics={key:dict(baseline=a[key],candidate=b[key],candidateOverBaseline=b[key]/a[key],improvement=(a[key]-b[key])/a[key]) for key in names}
        categories[name]=dict(metrics=metrics,meanImprovement=sum(r['improvement'] for r in metrics.values())/len(names))
    return dict(categories=categories,equalCategoryMeanImprovement=sum(c['meanImprovement'] for c in categories.values())/3,
        buildTotal=dict(baseline=a['build_total_sec'],candidate=b['build_total_sec'],candidateOverBaseline=b['build_total_sec']/a['build_total_sec']),
        scope='Same-host incremental descriptive A/B only. Separate from unchanged scorer versus fixed CI reference.',
        statisticalSignificanceClaimed=False,formalContestRun=False)


import io


import zipfile


from types import SimpleNamespace


ARCHIVES={
 'baseline':dict(expiresAtUtc='2026-11-13T11:01:41Z',artifactId=13757273442,runId=42797329842,zipBytes=328426886,
   zipSha256='02799ccf9fe5ff358cb6cb2403442ce1f3626dce80d211044636256c94140e96',
   member='candidate-build/candidate-elf.tar.gz',tarBytes=329567024,
   tarSha256='964858da1ad7bcc70fbfff20a9ac2df8ea758512a123c6f7d492d73138fcddf0'),
 'candidate':dict(expiresAtUtc='2026-11-14T04:35:16Z',artifactId=13828533821,runId=42953505169,zipBytes=329563859,
   zipSha256='76f1429ba1c2064d5421205f85f53eef0feac2055229103b92cf05f07dfbc0e5',
   member='candidate-elf.tar.gz',tarBytes=329540878,
   tarSha256='5813bb2323846ada22bcdb81555fa54063438f98df8f482ba4d248782a39196f')}


def extract_pinned(path,destination,contract,elf_contract):
    path=regular(path)
    require(path.stat().st_size==contract['zipBytes'] and sha(path)==contract['zipSha256'],'Exact original artifact ZIP missing/mismatched; expired artifacts must stop, never substitute')
    destination.parent.mkdir(parents=True,exist_ok=True)
    require(not destination.exists(),'Refuse to replace existing role ELF')
    with zipfile.ZipFile(path) as z:
        names=z.namelist()
        require(len(names)==len(set(names)) and len(names)<5000,'Duplicate/unbounded ZIP inventory')
        info=z.getinfo(contract['member'])
        require(info.file_size==contract['tarBytes'] and not stat.S_ISLNK(info.external_attr>>16),'Pinned inner tar missing/link/size mismatch')
        data=z.read(info)
    require(hashlib.sha256(data).hexdigest()==contract['tarSha256'],'Inner TAR SHA256 mismatch')
    with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as tar:
        members=tar.getmembers()
        require(len(members)==1 and members[0].name=='candidate/seekdb' and members[0].isreg()
                and members[0].size==elf_contract['bytes'],'Pinned ELF member must be sole regular candidate/seekdb')
        with tar.extractfile(members[0]) as src,destination.open('xb') as dst:shutil.copyfileobj(src,dst,4*1024**2)
    require(sha(destination)==elf_contract['sha256'],'Extracted ELF SHA256 mismatch')
    with destination.open('rb') as f:require(f.read(4)==b'\x7fELF','Extracted artifact is not ELF')
    destination.chmod(0o555)
    return dict(archive=contract,elf=elf_contract,extractedPath=str(destination),actualZipTarElfVerified=True)


def one_zip(directory):
    entries=list(directory.iterdir()) if directory.is_dir() else []
    require(len(entries)==1 and entries[0].is_file() and not entries[0].is_symlink(),'Exactly one downloaded original ZIP required; unavailable/expired stops here')
    return entries[0]


def collect(root,out,download_outcomes,deadline=None):
    deadline=deadline if deadline is not None else time.monotonic()+180
    require(not out.resolve().is_relative_to(root.resolve()),'Evidence destination must be outside the owned run directory')
    require(not out.exists(),'Fresh evidence output required')
    out.mkdir(parents=True)
    allowed={'.json','.txt','.log','.sql','.gz'}
    manifest=[]
    for path in sorted(root.rglob('*')):
        rel=path.relative_to(root)
        if {'runtime','vendor','client','downloads','database','tmp'} & set(rel.parts):continue
        if not path.is_file() or path.is_symlink() or path.suffix not in allowed:continue
        require(path.stat().st_size<=2*1024**3,'Evidence file too large; do not truncate')
        check_deadline(deadline,'evidence collection')
        dest=out/rel;dest.parent.mkdir(parents=True,exist_ok=True);working=dest.with_name(dest.name+'.partial')
        before=stamp(path)
        with path.open('rb') as src,working.open('xb') as dst:shutil.copyfileobj(DeadlineReader(src,deadline,'evidence copy'),dst,4*1024**2)
        require(stamp(path)==before,'Evidence source changed during collection')
        digest=deadline_sha(working,deadline);working.replace(dest)
        manifest.append(dict(path=rel.as_posix(),bytes=dest.stat().st_size,sha256=digest))
    report=json.loads((root/'report.json').read_text()) if (root/'report.json').is_file() else {}
    completed=report.get('status')=='original_full_pair_completed_local_only'
    started=[(name,row) for name,row in report.get('roles',{}).items() if row.get('start') or row.get('fullServerLogs') or row.get('retainedDatabaseDirectory')]
    missing_capture=[name for name,row in started if not row.get('fullServerLogs',{}).get('allExistingStoppedLogBytesPreserved')]
    missing_expected={name:row.get('fullServerLogs',{}).get('missingExpectedLogs',[]) for name,row in started if not row.get('fullServerLogs',{}).get('requiredLogsPresent')}
    retained={name:row['retainedDatabaseDirectory'] for name,row in started if row.get('retainedDatabaseDirectory')}
    dump(out/'collection.json',dict(files=manifest,downloadOutcomes=download_outcomes,formalContestRun=False,
        result='completed_local_only' if completed else 'blocked_or_incomplete_no_performance_verdict',
        artifacts=ARCHIVES,expiredArtifactPolicy='Stop; no alternative version, rebuild, Space fallback, token export or replacement',
        copiedLogFilesUntruncated=True,allExistingStoppedOwnedLogBytesPreserved=not missing_capture,
        missingFullLogCaptureRoles=missing_capture,missingExpectedLogsByRole=missing_expected,retainedDatabaseLogsNotUploaded=retained,
        allExpectedServerLogsPresent=not missing_expected,excludes=['runtime','vendor','client','downloads','database','tmp']))


def verify_bundle(bundle):
    manifest_path = regular(bundle / 'bundle-manifest.json')
    manifest = json.loads(manifest_path.read_text())
    inventory = manifest['originalInputs']
    encoded = json.dumps(inventory, sort_keys=True, separators=(',', ':')).encode()
    require(len(inventory) == 75 and hashlib.sha256(encoded).hexdigest() == INVENTORY_SHA,
            'Pinned original 75-input inventory mismatch')
    require(manifest['binaryIdentities'] == IDENTITIES and manifest['fixedConfig'] == CONFIG
            and manifest['databaseParameters'] == PARAMETERS, 'Portable contract differs from pinned values')
    for rel, expected in manifest['payloadHashes'].items():
        path = Path(rel)
        require(not path.is_absolute() and '..' not in path.parts, 'Unsafe manifest path')
        actual = regular(bundle / path)
        require(actual.resolve().is_relative_to(bundle.resolve()), 'Manifest member escapes bundle')
        require(sha(actual) == expected, 'Bundle hash mismatch: ' + rel)
    for rel, expected in inventory.items():
        require(manifest['payloadHashes'].get('inputs/' + rel) == expected, 'Original input missing from payload: ' + rel)
    return dict(manifestSha256=sha(manifest_path), originalInputCount=75, inventorySha256=INVENTORY_SHA,
                payloadFileCount=len(manifest['payloadHashes']))


def guard_window(args):
    require(args.pair_timeout_seconds>=required_pair_budget(args),'Pair timeout must include all explicit stage caps')
    require(args.total_timeout_seconds >= required_budget(args), 'Total timeout cannot cover both worst-case role budgets')
    require(args.window_deadline_utc, 'An operator-selected stop deadline is required; it is not a verified lease expiry')
    remaining=(instant(args.window_deadline_utc)-now()).total_seconds()
    require(remaining >= args.total_timeout_seconds+args.window_buffer_seconds,'Insufficient remaining window for full bounded A/B and cleanup')
    if args.ui_estimate_as_of_utc:instant(args.ui_estimate_as_of_utc)
    return dict(checkedUtc=utc(),operatorStopDeadlineUtc=instant(args.window_deadline_utc).isoformat(),remainingSeconds=remaining,
        deadlineKind='operator_selected_stop_deadline_not_lease_expiry',leaseExpiryVerified=False,physicalHostExclusivityVerified=False,
        remainingUiEstimate=args.remaining_ui_estimate,remainingUiEstimateAsOfUtc=args.ui_estimate_as_of_utc,
        plannedWorstCaseSeconds=required_budget(args),tinyTimeoutSeconds=900,pairTimeoutSeconds=args.pair_timeout_seconds,totalTimeoutSeconds=args.total_timeout_seconds,windowBufferSeconds=args.window_buffer_seconds)


def guard_attestations(args):
    require(args.confirm_exclusive_window,'Run requires confirmation of this container task window, not physical-host exclusivity')
    for label,value in [('container task idle',args.idle_attested_at_utc),('observed GPU utilization idle',args.gpu_idle_attested_at_utc)]:
        require(value, 'Missing external '+label+' verification timestamp')
        age=(now()-instant(value)).total_seconds()
        require(-10 <= age <= args.attestation_max_age_seconds,label+' verification is stale or in the future; recheck before run')
    return dict(operatorConfirmedContainerTaskWindow=True,containerIdleAttestedUtc=args.idle_attested_at_utc,
        gpuUtilizationIdleObservedAtUtc=args.gpu_idle_attested_at_utc,maxAgeSeconds=args.attestation_max_age_seconds,
        physicalHostExclusivityVerified=False,unknownHostGpuProcessCount=args.unknown_host_gpu_process_count,
        hostGpuObservationNote=args.host_gpu_observation_note,
        note='Only this container FTS task window is coordinated; physical host ownership/unknown KFD PIDs are not verified')


def fresh_root(path,bundle,args):
    path=Path(path).absolute()
    require(not path.exists() and not path.is_symlink(),'Run directory must be new and exclusive, never reused')
    require(path.parent.is_dir(),'Run directory parent must already exist')
    resolved=path.parent.resolve()/path.name
    protected=[bundle.resolve(),Path.cwd().resolve(),Path.home().resolve()]
    for value in (args.baseline_elf,args.candidate_elf,args.obclient):
        if value: protected.append(Path(value).resolve())
    require(resolved != Path(resolved.anchor) and all(resolved!=p and resolved not in p.parents for p in protected),'Run directory overlaps a protected path')
    require(not resolved.is_relative_to(bundle.resolve()),'Run outputs must be outside the immutable bundle')
    resolved.mkdir(mode=0o700)
    dump(resolved/'.fts-owned-run.json',dict(uuid=str(uuid.uuid4()),createdUtc=utc(),bundle=str(bundle.resolve()),purpose='One original full baseline/candidate FTS diagnostic'))
    return resolved


def parser():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--mode',choices=['check-bundle','extract','collect','preflight','run'],default='check-bundle')
    p.add_argument('--bundle-root',type=Path,default=Path(__file__).resolve().parent.parent)
    p.add_argument('--run-root',type=Path)
    p.add_argument('--baseline-zip',type=Path);p.add_argument('--candidate-zip',type=Path);p.add_argument('--evidence-out',type=Path)
    p.add_argument('--baseline-elf',type=Path);p.add_argument('--candidate-elf',type=Path)
    p.add_argument('--obclient',type=Path);p.add_argument('--mysqltest',type=Path)
    p.add_argument('--library-dir',action='append',default=[],type=Path)
    p.add_argument('--cpus',type=cpu_set)
    p.add_argument('--baseline-port',type=positive,default=7681);p.add_argument('--candidate-port',type=positive,default=7682)
    p.add_argument('--role-timeout-seconds',type=positive,choices=[600],default=600)
    p.add_argument('--ready-timeout-seconds',type=positive,default=180)
    p.add_argument('--total-timeout-seconds',type=positive,default=3900)
    p.add_argument('--pair-timeout-seconds',type=positive,default=3000)
    p.add_argument('--log-capture-reserve-seconds',type=positive,default=120)
    p.add_argument('--window-buffer-seconds',type=positive,default=120)
    p.add_argument('--stop-deadline-utc','--window-deadline-utc',dest='window_deadline_utc',help='Operator-selected stop deadline, NOT a verified lease expiry')
    p.add_argument('--remaining-ui-estimate',help='UI estimate copied as an estimate, e.g. about one hour')
    p.add_argument('--ui-estimate-as-of-utc')
    p.add_argument('--confirm-exclusive-window',action='store_true',help='Confirm only this container FTS task window; no physical-host exclusivity claim')
    p.add_argument('--unknown-host-gpu-process-count',type=int,default=0)
    p.add_argument('--host-gpu-observation-note',default='Physical-host GPU process ownership/exclusivity is unverified')
    p.add_argument('--idle-attested-at-utc');p.add_argument('--gpu-idle-attested-at-utc')
    p.add_argument('--attestation-max-age-seconds',type=positive,default=120)
    p.add_argument('--observation-seconds',type=positive,default=2)
    p.add_argument('--min-memory-gib',type=positive,default=6);p.add_argument('--min-disk-gib',type=positive,default=12)
    return p


def main(argv=None):
    args=parser().parse_args(argv);bundle=args.bundle_root.resolve()
    verification=verify_bundle(bundle)
    if args.mode=='check-bundle':
        emit(dict(status='offline_bundle_check_passed',**verification,sqlTestsRun=0,databaseStarts=0,
            fixedConfig=CONFIG,databaseParameters=PARAMETERS,requiredDefaultExecutionBudgetSeconds=required_budget(args)))
        return 0
    if args.mode=='extract':
        require(args.run_root is not None and args.baseline_zip is not None and args.candidate_zip is not None,'Extract needs a fresh run-root and both pinned local ZIP paths')
        root=fresh_root(args.run_root,bundle,args)
        receipts={role:extract_pinned(getattr(args,role+'_zip'),root/'runtime'/role/'seekdb',ARCHIVES[role],IDENTITIES[role]) for role in ('baseline','candidate')}
        dump(root/'extraction.json',receipts)
        emit(dict(status='pinned_local_zip_tar_elf_extracted_no_execution',runRoot=str(root),databaseStarts=0,sqlTestsRun=0))
        return 0
    if args.mode=='collect':
        require(args.run_root is not None and args.evidence_out is not None,'Collect needs owned run-root and a fresh evidence-out')
        marker=args.run_root/'.fts-owned-run.json'
        require(marker.is_file() and json.loads(marker.read_text()).get('bundle')==str(bundle.resolve()),'Only this bundle-owned run directory may be collected')
        collect(args.run_root,args.evidence_out,dict(baseline='local pinned input',candidate='local pinned input'))
        emit(dict(status='owned_evidence_collected',out=str(args.evidence_out),databaseStarts=0,sqlTestsRun=0))
        return 0
    for key in ('run_root','baseline_elf','candidate_elf','obclient'):
        require(getattr(args,key) is not None,'Required for runtime mode: --'+key.replace('_','-'))
    require(args.baseline_port!=args.candidate_port and max(args.baseline_port,args.candidate_port)<=65535,'Use distinct valid role ports')
    if args.mode=='run':
        require(args.cpus is not None,'Actual run requires an explicit CPU set chosen from remote preflight')
        guard_attestations(args);guard_window(args)
    available=os.sched_getaffinity(0)
    if args.cpus:
        require(args.cpus<=available,'Requested CPUs are not allowed in this environment')
        os.sched_setaffinity(0,args.cpus)
    root=fresh_root(args.run_root,bundle,args);env=runtime_env(args)
    report=dict(status='preflight_running',startedUtc=utc(),mode=args.mode,bundleVerification=verification,
        fixedConfig=CONFIG,databaseParameters=PARAMETERS,roles={},formalContestRun=False,newBuilds=0,
        requestedCpuSet=sorted(args.cpus) if args.cpus else None,actualRunnerAffinity=sorted(os.sched_getaffinity(0)),
        runtimeLibraryDirectories=[str(Path(p).resolve()) for p in args.library_dir],
        runnerVersion=2,tinyTimeoutSeconds=900,pairTimeoutSeconds=args.pair_timeout_seconds,totalSessionTimeoutSeconds=args.total_timeout_seconds,
        baselineRebuilt=False,originalScorer=True,frozenBaselineModified=False,originalNativeInitializer=False,
        pairComparisonStatus='not_available_unless_both_full_roles_complete',
        physicalHostExclusivityVerified=False,leaseExpiryVerified=False,
        remainingUiEstimate=args.remaining_ui_estimate,remainingUiEstimateAsOfUtc=args.ui_estimate_as_of_utc,
        unknownHostGpuProcessCount=args.unknown_host_gpu_process_count,hostGpuObservationNote=args.host_gpu_observation_note,
        portableGitMetadata='No git checkout required. Original report may say git_head=unknown/git_dirty=1. Manifest proves immutable copied inputs.',
        limitations=['One baseline then one candidate; order bias is not removed.',
            'Only this container task window is coordinated. Physical-host exclusivity and unknown host KFD PIDs are unverified.',
            'Stop deadline is operator-selected, not a verified lease expiry. UI remaining-time estimates may change.',
            'One build timing per index/role; only three internal SQL-loop samples.',
            'Fixed-reference scorer output is a local result, not a formal contest score.',
            'No statistical significance or official pass is claimed.'])
    dump(root/'report.json',report)
    try:
        snapshot=resources(root);dump(root/'resources-preflight.json',snapshot);require_resources(snapshot,args)
        obs=process_observation(args.observation_seconds);dump(root/'global-processes-preflight.json',obs)
        guard_processes(obs);gpu_observation(root,env)
        for port in (args.baseline_port,args.candidate_port):
            with socket.socket() as probe:probe.bind(('127.0.0.1',port))
        identities=verify_runtime(args,root,env);report['runtimeIdentities']=identities
        if args.mode=='preflight':
            report.update(status='runtime_preflight_passed_no_database_started',finishedUtc=utc(),databaseStarts=0,sqlTestsRun=0)
            if args.window_deadline_utc:report['windowCheck']=guard_window(args)
            dump(root/'report.json',report);emit(dict(status=report['status'],runRoot=str(root),affinity=snapshot['affinity'],databaseStarts=0));return 0
        report['attestations']=guard_attestations(args);report['windowCheck']=guard_window(args)
        # Process-local adoption enables original sdb stop to observe reaped exits.
        require(ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0,'Cannot adopt own detached daemon children safely')
        overall_deadline=time.monotonic()+args.total_timeout_seconds
        def interrupted(signum,frame):raise Blocked('Operator interrupted; cleaning owned processes and preserving receipts')
        signal.signal(signal.SIGTERM,interrupted);signal.signal(signal.SIGINT,interrupted)
        generated=root/'generated-input-identity.json'
        gen=bundle/'inputs/tools/benchmark/fts_large_bench_gen.py'
        command=[sys.executable,'-B',str(gen),'--rows','20000','--batch','500']
        require(overall_deadline-time.monotonic()>30+900+required_pair_budget(args),'Insufficient full-session reserve before generator')
        (root/'tmp').mkdir();sql_path=root/'tmp/generated-input.sql'
        generator_receipt=checked(command,sql_path,env,30)
        require(deadline_sha(sql_path,min(time.monotonic()+30,overall_deadline))==DATA_SHA,'Unchanged generator output identity mismatch')
        dump(generated,dict(command=command,commandReceipt=generator_receipt,bytes=sql_path.stat().st_size,sha256=DATA_SHA,seed=42,largeInsertPayloadExcludedFromEvidence=True))
        tiny_deadline=min(overall_deadline-required_pair_budget(args),time.monotonic()+900)
        tiny=run_role('baseline',args.baseline_port,args,bundle,root,env,identities,report,tiny_deadline,name='baseline-tiny')
        require(tiny['status']=='completed' and tiny['cleanupPassed'],'Tiny original-setup gate failed; no full pair')
        deadline=min(overall_deadline,time.monotonic()+args.pair_timeout_seconds)
        for role,port in [('baseline',args.baseline_port),('candidate',args.candidate_port)]:
            row=run_role(role,port,args,bundle,root,env,identities,report,deadline)
            require(row['status']=='completed' and row['cleanupPassed'],role+' benchmark/cleanup did not complete; do not run more roles')
        check_deadline(overall_deadline,'session completion')
        report['sameHostIncrementalComparison']=comparison(report)
        dump(root/'same-host-incremental.json',report['sameHostIncrementalComparison'])
        report.update(status='original_full_pair_completed_local_only',finishedUtc=utc(),originalInputsUnchanged=True,
            pairComparisonStatus='complete_descriptive_local_only')
    except Exception as exc:
        report.update(status='blocked',error=str(exc),traceback=traceback.format_exc(),finishedUtc=utc())
    finally:
        dump(root/'resources-final.json',resources(root));dump(root/'global-processes-final.json',process_observation(args.observation_seconds))
        dump(root/'report.json',report)
    emit(dict(status=report['status'],runRoot=str(root),error=report.get('error'),formalContestRun=False))
    return 0 if report['status']=='original_full_pair_completed_local_only' else 1


def required_budget(args):
    return 900+required_pair_budget(args)+30

if __name__=='__main__':
    try:raise SystemExit(main())
    except Blocked as exc:
        emit(dict(status='blocked',error=str(exc)));raise SystemExit(2)
