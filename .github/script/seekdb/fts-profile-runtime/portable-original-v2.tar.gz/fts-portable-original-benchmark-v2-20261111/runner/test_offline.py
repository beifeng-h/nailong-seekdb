import contextlib


import datetime as dt


import hashlib


import io


import json


from pathlib import Path


import tempfile


import unittest


from unittest.mock import patch


import tarfile


import zipfile


import run_pair as h


def fixture(root,kind='regular',name='candidate/seekdb',duplicate=False):
    elf=b'\x7fELFsmall-test-fixture-not-executable'
    raw=io.BytesIO()
    with tarfile.open(fileobj=raw,mode='w:gz') as t:
        entry=tarfile.TarInfo(name)
        if kind=='regular':entry.size=len(elf);t.addfile(entry,io.BytesIO(elf))
        else:entry.type=tarfile.SYMTYPE;entry.linkname='/etc/passwd';t.addfile(entry)
    data=raw.getvalue();p=root/'fixture.zip'
    with zipfile.ZipFile(p,'w') as z:
        z.writestr('candidate-elf.tar.gz',data)
        if duplicate:
            import warnings
            with warnings.catch_warnings():warnings.simplefilter('ignore');z.writestr('candidate-elf.tar.gz',data)
    contract=dict(zipBytes=p.stat().st_size,zipSha256=h.sha(p),member='candidate-elf.tar.gz',tarBytes=len(data),tarSha256=hashlib.sha256(data).hexdigest())
    return p,contract,dict(bytes=len(elf),sha256=hashlib.sha256(elf).hexdigest())


BUNDLE=Path(__file__).resolve().parent.parent

def fixture_args(source,root):
    args=h.parser().parse_args([])
    args.bundle_root=source;args.run_root=root;args.obclient=Path('/fixture/official-obclient');args.mysqltest=None
    args.cpus=set(h.os.sched_getaffinity(0));args.window_deadline_utc=(h.now()+dt.timedelta(hours=2)).isoformat()
    return args

class PortableCoreV2(unittest.TestCase):
    def test_plan_default_has_no_runtime(self):
        with patch.object(h,'run_role',side_effect=AssertionError('No DB')),contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(h.main(['--bundle-root',str(BUNDLE)]),0)


    def test_fixed_original_contract(self):
        self.assertEqual(h.CONFIG,dict(ROWS='20000',BATCH='500',ROUNDS='3000',QUERY_ROUNDS='200',SAMPLES='3',WARMUP='30',SKIP_LOAD='0'))
        self.assertEqual(sum(map(len,h.CATEGORIES.values())),9)
        self.assertEqual(h.HITS,dict(query_cn_hits=8001,query_beng_hits=11000,query_mixed_hits=7332,query_limit_hits=20))


    def test_pinned_actual_artifacts(self):
        self.assertEqual(h.ARCHIVES['baseline']['artifactId'],13757273442)
        self.assertEqual(h.ARCHIVES['candidate']['artifactId'],13828533821)
        self.assertEqual(h.ARCHIVES['baseline']['expiresAtUtc'],'2026-11-13T11:01:41Z')
        self.assertEqual(h.ARCHIVES['candidate']['expiresAtUtc'],'2026-11-14T04:35:16Z')


    def test_exact_fixture_extract(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);p,c,e=fixture(root)
            receipt=h.extract_pinned(p,root/'runtime/seekdb',c,e)
            self.assertTrue(receipt['actualZipTarElfVerified'])
            self.assertEqual(h.sha(root/'runtime/seekdb'),e['sha256'])


    def test_outer_hash_hard_failure(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);p,c,e=fixture(root);c['zipSha256']='0'*64
            with self.assertRaises(h.Blocked):h.extract_pinned(p,root/'out/seekdb',c,e)


    def test_tar_hash_hard_failure(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);p,c,e=fixture(root);c['tarSha256']='0'*64
            with self.assertRaises(h.Blocked):h.extract_pinned(p,root/'out/seekdb',c,e)


    def test_elf_hash_hard_failure(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);p,c,e=fixture(root);e['sha256']='0'*64
            with self.assertRaises(h.Blocked):h.extract_pinned(p,root/'out/seekdb',c,e)


    def test_link_and_traversal_are_not_extractable(self):
        for options in [dict(kind='link'),dict(name='../../escape'),dict(duplicate=True)]:
            with self.subTest(options=options),tempfile.TemporaryDirectory() as d:
                root=Path(d);p,c,e=fixture(root,**options)
                with self.assertRaises(h.Blocked):h.extract_pinned(p,root/'out/seekdb',c,e)
                self.assertFalse((root/'escape').exists())


    def test_missing_artifact_stops_without_fallback(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(h.Blocked):h.one_zip(Path(d)/'missing')


    def test_token_not_passed_to_runtime_helpers(self):
        args=type('Args',(),dict(obclient=Path('/official/obclient'),library_dir=[]))()
        with patch.dict(h.os.environ,{'GITHUB_TOKEN':'fixture-secret-not-a-real-token','ACTIONS_RUNTIME_TOKEN':'fixture-2'}):
            env=h.runtime_env(args)
            self.assertNotIn('GITHUB_TOKEN',env);self.assertNotIn('ACTIONS_RUNTIME_TOKEN',env)
            self.assertNotIn('fixture-secret-not-a-real-token',str(env))


    def test_namespace_and_lease_claims_are_false(self):
        args=fixture_args(Path('/source'),Path('/root'))
        result=h.guard_window(args)
        self.assertFalse(result['leaseExpiryVerified'])
        self.assertFalse(result['physicalHostExclusivityVerified'])
        self.assertEqual(h.required_pair_budget(args),2740)


    def test_collect_does_not_ship_elf_or_database(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'owned';out=Path(d)/'evidence';root.mkdir()
            (root/'runtime').mkdir();(root/'runtime/seekdb').write_text('fixture ELF')
            (root/'baseline/database').mkdir(parents=True);(root/'baseline/database/datafile').write_text('fixture private data')
            (root/'baseline/benchmark.log').write_text('complete fixture log\n'*1000)
            h.collect(root,out,dict(baseline='failure',candidate='skipped'))
            self.assertFalse((out/'runtime').exists());self.assertFalse((out/'baseline/database').exists())
            self.assertEqual((out/'baseline/benchmark.log').read_bytes(),(root/'baseline/benchmark.log').read_bytes())
            self.assertEqual(json.loads((out/'collection.json').read_text())['result'],'blocked_or_incomplete_no_performance_verdict')


    def test_busy_refuses_new_role(self):
        with self.assertRaises(h.Blocked):h.guard_processes(dict(foreignRelated=[dict(comm='seekdb')],foreignActive=[]))


    def test_tiny_setup_gate_never_runs_benchmark_or_scorer(self):
        import shutil
        from types import SimpleNamespace
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'owned';root.mkdir();source=Path(d)/'source'
            setup=source/'inputs/tools/benchmark/fts_large_bench_setup.sql';setup.parent.mkdir(parents=True)
            official=BUNDLE/'inputs/tools/benchmark/fts_large_bench_setup.sql'
            setup.write_bytes(official.read_bytes())
            binary=root/'runtime/baseline/seekdb';binary.parent.mkdir(parents=True);binary.write_bytes(b'fixture not executed')
            args=fixture_args(source,root);args.cpus={0,1};args.observation_seconds=1
            identities=dict(baseline=dict(path=str(binary),fileStamp=h.stamp(binary)),obclient=dict(path='/fixture/official-obclient'))
            report=dict(roles={});base=root/'baseline-tiny/database';calls=[];setup_inputs=[]
            sdb=SimpleNamespace(inspect_instance_process=lambda *_:424242,
                read_process_arguments=lambda *_:[str(binary),'--base-dir='+str(base)],
                read_instance_binary=lambda *_:binary.resolve())
            snapshot=dict(effectiveMemAvailableBytes=8*1024**3,diskFreeBytes=30*1024**3,affinity=[0,1],
                nofileLimit=[16384,16384],interfaces='head\nhead\n lo: 0\n eth0: 0\n')
            obs=dict(foreignRelated=[],foreignActive=[],processes=[])
            def fake_checked(command,output,env,timeout=30,input_bytes=None):
                words=list(map(str,command));calls.append(words)
                if any(w.endswith(('fts_large_bench.sh','fts_large_bench_score.py')) for w in words):
                    raise AssertionError('Tiny gate must never run full benchmark/scorer')
                output.parent.mkdir(parents=True,exist_ok=True)
                if output.name=='start.log':
                    (base/'run').mkdir(parents=True);(base/'run/seekdb.pid').write_text('424242');output.write_text('started pid=424242\n')
                elif output.name=='actual-parameters.log':
                    output.write_text('cpu_count\t2\ndatafile_maxsize\t2G\ndatafile_size\t32M\nlog_disk_size\t2G\nmemory_budget\t4G\nsyslog_level\tEDIAG\nvector_memory_limit\t1G\n')
                elif output.name=='original-benchmark-setup.log':setup_inputs.append(input_bytes);output.write_text('')
                elif output.name=='tiny-sql.log':output.write_text('1\n0\n["the","quick","brown","fox"]\n')
                else:output.write_text('ok\n')
                if 'destroy' in words:shutil.rmtree(base)
                return dict(exitCode=0)
            actual_resolve=Path.resolve
            def fake_resolve(path,*a,**kw):
                if str(path)=='/proc/424242/exe':return binary
                return actual_resolve(path,*a,**kw)
            with patch.object(h,'verify_bundle',return_value={}),patch.object(h,'resources',return_value=snapshot),\
                 patch.object(h,'process_observation',return_value=obs),patch.object(h,'gpu_observation',return_value={}),\
                 patch.object(h,'load_sdb',return_value=sdb),patch.object(h,'checked',side_effect=fake_checked),\
                 patch.object(h,'state',return_value=dict(state='R',startTicks=1)),patch.object(h.os,'sched_getaffinity',return_value={0,1}),\
                 patch.object(h.socket,'socket'),patch.object(h.threading,'Thread'),patch.object(h,'capture_logs',return_value=dict(fullBytes=True,requiredLogsPresent=True,allExistingStoppedLogBytesPreserved=True)),\
                 patch.object(h,'role_evidence',return_value={}),patch.object(Path,'resolve',fake_resolve),contextlib.redirect_stdout(io.StringIO()):
                row=h.run_role('baseline',7690,args,source,root,{},identities,report,h.time.monotonic()+1200,name='baseline-tiny')
            self.assertEqual(row['status'],'completed',row.get('error'))
            self.assertTrue(row['tinyOriginalSetupPreflight']);self.assertTrue(row['cleanupPassed'])
            self.assertEqual(setup_inputs,[official.read_bytes()])
            self.assertFalse(any(w.endswith(('fts_large_bench.sh','fts_large_bench_score.py')) for cmd in calls for w in cmd))
            self.assertFalse(any(name.startswith('benchmark') for name in row))


    def test_console_only_startup_failure_reaches_role_and_final_evidence(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'owned';role=root/'baseline';base=role/'database';log=base/'log'
            log.mkdir(parents=True);fatal=(b'FATAL startup fixture, no main log yet\n'*1000)
            (log/'console.log').write_bytes(fatal)
            receipt=h.capture_logs(base,role,None)
            self.assertTrue(receipt['allExistingStoppedLogBytesPreserved'])
            self.assertFalse(receipt['requiredLogsPresent']);self.assertEqual(receipt['missingExpectedLogs'],['log/seekdb.log'])
            with tarfile.open(role/'full-server-logs.tar.gz') as logs:
                self.assertEqual(logs.extractfile('log/console.log').read(),fatal)
            h.dump(role/'result.json',dict(status='blocked',start=dict(exitCode=0),fullServerLogs=receipt))
            h.dump(root/'report.json',dict(status='blocked',roles=dict(baseline=dict(start=dict(exitCode=0),fullServerLogs=receipt))))
            with contextlib.redirect_stdout(io.StringIO()):archive=h.role_evidence(role,root)
            with tarfile.open(archive['path']) as evidence:
                payload=evidence.extractfile('baseline/full-server-logs.tar.gz').read()
                with tarfile.open(fileobj=io.BytesIO(payload)) as logs:self.assertEqual(logs.extractfile('log/console.log').read(),fatal)
            out=Path(d)/'collected';h.collect(root,out,dict(baseline='success',candidate='success'))
            with tarfile.open(out/'baseline/full-server-logs.tar.gz') as logs:self.assertEqual(logs.extractfile('log/console.log').read(),fatal)
            summary=json.loads((out/'collection.json').read_text())
            self.assertTrue(summary['allExistingStoppedOwnedLogBytesPreserved'])
            self.assertFalse(summary['allExpectedServerLogsPresent'])
            self.assertEqual(summary['result'],'blocked_or_incomplete_no_performance_verdict')


    def test_log_cap_failure_is_not_advertised_as_complete(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'owned';root.mkdir()
            row=dict(start=dict(exitCode=0),cleanupError='Complete logs exceed capture cap',retainedDatabaseDirectory=str(root/'baseline/database'))
            h.dump(root/'report.json',dict(status='blocked',roles=dict(baseline=row)))
            out=Path(d)/'collected';h.collect(root,out,dict(baseline='success',candidate='skipped'))
            summary=json.loads((out/'collection.json').read_text())
            self.assertFalse(summary['allExistingStoppedOwnedLogBytesPreserved'])
            self.assertEqual(summary['missingFullLogCaptureRoles'],['baseline'])
            self.assertIn('baseline',summary['retainedDatabaseLogsNotUploaded'])


    def test_interrupt_reaps_created_group_and_writes_receipt_before_rethrow(self):
        from unittest.mock import Mock
        for command in [['python3','sdb.py','start'],['bash','fts_large_bench.sh'],['obclient','-e','fixture']]:
            with self.subTest(command=command),tempfile.TemporaryDirectory() as d:
                process=Mock(pid=424242,returncode=None)
                process.poll.return_value=None
                process.communicate.side_effect=h.Blocked('fixture cancellation')
                def waited(*a,**kw):process.returncode=-15;return -15
                process.wait.side_effect=waited
                output=Path(d)/'command.log'
                with patch.object(h.subprocess,'Popen',return_value=process),patch.object(h.os,'getpgid',return_value=424242),\
                    patch.object(h.os,'killpg') as kill,patch.object(h,'proc_snapshot',return_value={}):
                    with self.assertRaisesRegex(h.Blocked,'fixture cancellation'):h.run_command(command,output,{},60)
                kill.assert_called_once_with(424242,h.signal.SIGTERM)
                self.assertTrue(process.wait.called)
                receipt=json.loads(output.with_name(output.name+'.receipt.json').read_text())
                self.assertTrue(receipt['interrupted']);self.assertTrue(receipt['createdGroupCleanedAndReaped'])
                self.assertEqual(receipt['exitCode'],-15)


    def test_launch_failure_still_writes_receipt_without_signal(self):
        with tempfile.TemporaryDirectory() as d,patch.object(h.subprocess,'Popen',side_effect=OSError('fixture missing executable')),patch.object(h.os,'killpg') as kill:
            output=Path(d)/'missing.log'
            with self.assertRaises(OSError):h.run_command(['fixture-no-executable'],output,{},10)
            kill.assert_not_called()
            self.assertEqual(json.loads(output.with_name(output.name+'.receipt.json').read_text())['exceptionType'],'OSError')


    def test_near_deadline_refuses_database_before_any_command(self):
        from types import SimpleNamespace
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'owned';root.mkdir();source=Path(d)/'source';source.mkdir()
            binary=root/'fixture-elf';binary.write_text('never executed')
            args=fixture_args(source,root);args.cpus={0,1}
            identities=dict(baseline=dict(path=str(binary),fileStamp=h.stamp(binary)),obclient=dict(path='/fixture/client'))
            with patch.object(h,'load_sdb',return_value=SimpleNamespace()),\
                patch.object(h,'verify_bundle',return_value={}),patch.object(h,'resources',return_value={}),\
                patch.object(h,'process_observation',return_value={}),patch.object(h,'role_evidence',return_value={}),\
                patch.object(h.time,'monotonic',return_value=0),patch.object(h,'checked') as command,contextlib.redirect_stdout(io.StringIO()):
                row=h.run_role('baseline',7681,args,source,root,{},identities,dict(roles={}),650)
            command.assert_not_called();self.assertEqual(row['status'],'blocked')
            self.assertIn('Insufficient complete next-role budget',row['error'])


    def test_active_sql_and_scorer_calls_all_have_deadline_admission(self):
        import ast,inspect
        node=ast.parse(inspect.getsource(h.run_role));matched=set()
        expected={'actual-parameters.log','original-benchmark-setup.log','tiny-sql.log','frozen-reference-score.json','frozen-reference-score.txt','untimed-samples.log'}
        for call in ast.walk(node):
            if isinstance(call,ast.Call) and isinstance(call.func,ast.Name) and call.func.id=='checked':
                strings={part.value for part in ast.walk(call.args[1]) if isinstance(part,ast.Constant) and isinstance(part.value,str)}
                names=strings&expected
                if names:
                    self.assertIsInstance(call.args[3],ast.Call)
                    self.assertEqual(call.args[3].func.id,'bounded');matched|=names
        self.assertEqual(matched,expected)


    def test_compression_reader_stops_at_fake_deadline(self):
        with patch.object(h.time,'monotonic',side_effect=[0,1,2]):
            reader=h.DeadlineReader(io.BytesIO(b'abcdef'),1.5,'fixture compression')
            self.assertEqual(reader.read(2),b'ab')
            with self.assertRaises(h.Blocked):reader.read(2)



    def test_main_run_orders_tiny_then_exact_pair_without_real_processes(self):
        from types import SimpleNamespace
        from unittest.mock import Mock
        with tempfile.TemporaryDirectory() as d:
            owned=Path(d)/'run';calls=[];fixture_sql=b'fixture generated SQL, never executed\n'
            snapshot=dict(effectiveMemAvailableBytes=8*1024**3,diskFreeBytes=30*1024**3,affinity=[0,1],
                nofileLimit=[16384,16384],interfaces='head\nhead\n lo: 0\n eth0: 0\n')
            obs=dict(foreignRelated=[],foreignActive=[],processes=[])
            def fake_checked(command,output,env,timeout=30,input_bytes=None):
                self.assertIn('fts_large_bench_gen.py',str(command));output.write_bytes(fixture_sql)
                return dict(exitCode=0,command=list(map(str,command)))
            def fake_role(role,port,args,bundle,root,env,identities,report,deadline,name=None):
                calls.append((role,name,args.role_timeout_seconds))
                return dict(status='completed',cleanupPassed=True)
            arguments=['--mode','run','--bundle-root',str(BUNDLE),'--run-root',str(owned),
                '--baseline-elf','/fixture/A','--candidate-elf','/fixture/B','--obclient','/fixture/client','--cpus','0,1',
                '--confirm-exclusive-window','--idle-attested-at-utc',h.utc(),'--gpu-idle-attested-at-utc',h.utc(),
                '--stop-deadline-utc',(h.now()+dt.timedelta(hours=2)).isoformat()]
            with patch.object(h,'verify_bundle',return_value={}),patch.object(h,'resources',return_value=snapshot),\
                patch.object(h,'process_observation',return_value=obs),patch.object(h,'gpu_observation',return_value={}),\
                patch.object(h,'verify_runtime',return_value={}),patch.object(h,'run_role',side_effect=fake_role),\
                patch.object(h,'checked',side_effect=fake_checked),patch.object(h,'comparison',return_value={}),\
                patch.object(h,'DATA_SHA',hashlib.sha256(fixture_sql).hexdigest()),patch.object(h.socket,'socket'),\
                patch.object(h.os,'sched_getaffinity',return_value={0,1}),patch.object(h.os,'sched_setaffinity'),\
                patch.object(h.ctypes,'CDLL',return_value=SimpleNamespace(prctl=Mock(return_value=0))),\
                patch.object(h.signal,'signal'),contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(h.main(arguments),0)
            self.assertEqual(calls,[('baseline','baseline-tiny',600),('baseline',None,600),('candidate',None,600)])
            report=json.loads((owned/'report.json').read_text())
            self.assertEqual(report['totalSessionTimeoutSeconds'],3900)
            self.assertFalse(report['formalContestRun'])

if __name__=='__main__':unittest.main(verbosity=2)
