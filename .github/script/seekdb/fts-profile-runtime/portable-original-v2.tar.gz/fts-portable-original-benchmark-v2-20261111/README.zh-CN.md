# 原始FTS benchmark便携诊断v2

这是待独立审阅通过后才可实际启动的v2。默认仅check-bundle，不启动DB。原历史包165469 bytes、SHA256 1c3c699d0b8193f398a4877665306279742bb7d83b8c6ee52a7d7209431c9c47保持immutable，**暂停实际使用**：旧35分钟预算没有覆盖全部辅助stage，不能把它当成完整总上限。本v2不覆盖旧包。

v2复制75项完全未改的官方输入，inventory SHA为f36e2d1c8aaabd3e9ffc4f8e3635defca6dc3046e3d575e6e73165fa8d80a135。产品源码、原benchmark/scorer/固定baseline JSON及SQL loops全部不改。没有GitHub、Library、浏览器、下载、上传、编译或自动发布依赖。仅使用操作者提供的本地已授权文件和现有官方client/libaio。

## 已修复的四项发布前审查问题

1. tiny gate参数名不再被DB parameter循环覆盖。完全mock的实际run_role和main测试证明：tiny只跑原setup、SELECT1/空表count/TOKENIZE；执行顺序为tiny→baseline A→candidate B，tiny不调用完整benchmark/scorer。
2. 早期启动失败仅有console.log时，先把实际存在的已停止owned日志逐字节归档；缺seekdb.log单独标blocker，不丢fatal console。超cap/deadline/保全失败明确列missing capture/retained directory，不能宣称完整取证。
3. 每个新建命令session/group遇到任意异常（包括SIGTERM/SIGINT引发的Blocked）都先终止/reap本函数创建的group，always写中断receipt，再向上抛出。取消发生在sdb start时，另检查本runner后代中精确ELF+base-dir匹配的自有daemon，使用原sdb targeted helper settle后再做stop/log/destroy。绝不全局kill或触碰他人任务。
4. 参数查询、原setup/tiny SQL、benchmark、两次scorer、untimed sample均要通过阶段deadline准入并保留340秒owned cleanup预算。日志/证据hash及压缩逐块检查deadline；未完成压缩只有.partial，不冒充最终包。near-deadline fixture确认不足下一整角色预算时根本不启动DB。

## 实际预算

原benchmark每角色cap固定600秒，原数据/loops/samples不缩减。完整pair的全部stage保守需求2740秒，pair cap默认3000秒（50分钟）。tiny单独最多900秒。整个SQL session（generator+tiny+pair，包括owned cleanup/日志）默认总cap3900秒（65分钟），另留120秒自定停止窗口buffer；执行前至少需67分钟自选窗口。真实3小时实例足够，但必须根据实时身份/余时独立核对，不把UI估计当租约保证。

preflight/extract不建DB；preflight会核实际ELF hash/BuildID、运行--version/ldd和端口probe。上述SQL session预算在runtime验证后开始；文件读取遇到OS/文件系统永久阻塞、SIGKILL或整实例突然丢失时，任何Python程序都无法保证最后上传，必须如实报告。自定stop deadline不等于provider lease expiry。physicalHostExclusivityVerified=false、leaseExpiryVerified=false始终记录；exclusive确认只指此容器FTS任务窗口。未知宿主KFD PIDs单独记录，不终止它们。本任务不启动GPU工作。

## 输入与流程模板

先由当前browser worker核实新实例身份、可见容器任务、GPU利用率、CPU quota/affinity、内存/磁盘和余时。不要把上一个实例的hostname/剩余时间沿用。CPU IDs不写死；只给本runner设置自己的affinity，两个真实server必须继承一致集合，实际cpu_count/所有DB参数也要一致。

以下模板仅在审核通过并获准后使用。变量全部换成远端实际绝对路径，目录必须全新且在bundle以外。obclient路径不能含空格。

    BUNDLE=/absolute/path/fts-portable-original-benchmark-v2-20261111
    python3 -B "$BUNDLE/runner/run_pair.py" --mode check-bundle --bundle-root "$BUNDLE"

如两份原ZIP已在本地，可只核验/解包，不执行ELF、不启动DB：

    ELFROOT=/absolute/path/new-owned-elf-extraction
    python3 -B "$BUNDLE/runner/run_pair.py" --mode extract --bundle-root "$BUNDLE" --run-root "$ELFROOT" --baseline-zip /absolute/path/b147-original.zip --candidate-zip /absolute/path/candidate-original.zip
    BASELINE="$ELFROOT/runtime/baseline/seekdb"
    CANDIDATE="$ELFROOT/runtime/candidate/seekdb"

完整ZIP、内层TAR、ELF pins全部硬核验；不接受其他版本。只按精确member读取，拒绝重复成员、链接、路径穿越，不使用extractall。预检还会重新核实际收到的两个ELF、大小、BuildID、内嵌commit和ldd；精确obclient必须是官方2.2.3所对应SHA 798aa952…；libaio解析到的实际文件/SONAME/hash须两边一致。仅在自有compat目录处理兼容链接，不能改系统共享库。

    OBCLIENT=/absolute/path/official/obclient
    CLIENT_LIB=/absolute/path/official/obclient/lib
    AIO_LIB=/absolute/path/owned/compat
    PREFLIGHT=/absolute/path/new-preflight-dir
    python3 -B "$BUNDLE/runner/run_pair.py" --mode preflight --bundle-root "$BUNDLE" --run-root "$PREFLIGHT" --baseline-elf "$BASELINE" --candidate-elf "$CANDIDATE" --obclient "$OBCLIENT" --library-dir "$CLIENT_LIB" --library-dir "$AIO_LIB"

预检不等于批准启动。独立审阅通过后，刷新容器任务/GPU观察（不超过120秒），选择实际允许CPU IDs和保守自定stop时间，再使用另一个全新RUN目录：

    CPU_IDS='<当前实际允许且两边一致的CPU IDs>'
    IDLE_AT='<本容器任务idle的UTC观察时间>'
    GPU_IDLE_AT='<观察到GPU利用率idle的UTC时间>'
    STOP_AT='<操作者自选UTC停止时间，非租约到期>'
    UI_AS_OF='<本次UI余时估计的UTC观察时间>'
    RUN=/absolute/path/new-full-session-dir
    python3 -B "$BUNDLE/runner/run_pair.py" --mode run --bundle-root "$BUNDLE" --run-root "$RUN" --baseline-elf "$BASELINE" --candidate-elf "$CANDIDATE" --obclient "$OBCLIENT" --library-dir "$CLIENT_LIB" --library-dir "$AIO_LIB" --cpus "$CPU_IDS" --baseline-port 7681 --candidate-port 7682 --role-timeout-seconds 600 --pair-timeout-seconds 3000 --total-timeout-seconds 3900 --window-buffer-seconds 120 --stop-deadline-utc "$STOP_AT" --confirm-exclusive-window --idle-attested-at-utc "$IDLE_AT" --gpu-idle-attested-at-utc "$GPU_IDLE_AT" --remaining-ui-estimate '<当前UI估计文字>' --ui-estimate-as-of-utc "$UI_AS_OF" --unknown-host-gpu-process-count '<已观察但此namespace无法识别的数量>' --host-gpu-observation-note '<当前可验证限制，不猜物理宿主独占>'

## 原始合同与取证

ROWS20000/BATCH500/ROUNDS3000/QUERY_ROUNDS200/SAMPLES3/WARMUP30/SKIP_LOAD0。memory_budget4G/vector_memory_limit1G/datafile_maxsize2G/log_disk_size2G。不跑旧native矩阵，不采用mysqltest failpoint initializer。

保留三build秒数、两TOKENIZE平均毫秒、四MATCH平均毫秒共九项；保存select1/load/build total、21条原sample timing原文、实际参数/affinity/资源、命令receipt与完整server console/log。hitcount必须8001/11000/7332/20。原benchmark将重复SQL结果重定向/dev/null不改；另在计时后收两TOKENIZE值和四原查询输出，标为untimed。

原scorer用未改的默认固定reference JSON，不用config waiver、不换reference、不换metric。固定reference结果仅本机描述，非正式比赛分数；same-host A/B比值另存。A后B顺序bias、每index一次build和三内部SQL样本都要注明，不声称统计显著性、官方PASS或native9/9。任一角色/cleanup/取证不完整就停止，不作完整A/B比较。

每个阶段只操作本bundle新建owned run目录。原sdb stop→现有完整日志保全→destroy；保全失败保留目录并明确状态，不清除唯一原日志。每角色结束即输出role_evidence_ready和独立baseline-tiny/baseline/candidate证据tar+SHA，可立即正常下载，不等最后。不得把.partial当完整结果。最终运行停止后，可将本bundle marker确认的owned结果收集到独立新目录（不含ELF/DB/tmp/大INSERT）：

    python3 -B "$BUNDLE/runner/run_pair.py" --mode collect --bundle-root "$BUNDLE" --run-root "$RUN" --evidence-out /absolute/path/new-evidence-dir

取证再通过正常browser/工具下载，runner自己不上传、不读凭据。全局进程只记录可见PID namespace的名称/ID/CPU metadata，不输出他人args/env。

## 当前验证状态

本轮仅syntax、manifest和22项完全离线fixture/mock检查；包括四项Major及实际main调用顺序。没有真实ELF启动、DB/SQL、9指标计时或scorer执行。review通过才允许实际run。此前独立云baseline启动失败不算本v2的真实SQL验证。
